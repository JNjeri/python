class Triangle:
  base = 0
  height = 0
  def __init__(self,base,height):
    self.base = base
    self.height = height
  def area(self):
      return self.height *self.base *0.5