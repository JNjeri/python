from flask import Flask
from triangle import Triangle
app = Flask(__name__)
@app.route("/")
def index(name = "student"):
  return"welcome {} to Akirachix".format(name)

@app.route("/welcome/<name>")
def welcome(name = "student"):
  return"welcome {} to Akirachix".format(name)

@app.route("/add/<int:num1>/<int:num2>")
@app.route("/add/<float:num1>/<float:num2>")
@app.route("/add/<int:num1>/<float:num2>")
def add(num1 = 0, num2 = 0):
  add = num1 + num2
  return "add of {} and {} is {}".format(num1,num2,add)
@app.route("/triangle/<int:base>/<int:height>")
@app.route("/triangle/<float:base>/<float:height>")
@app.route("/triangle/<int:base>/<float:height>")
def triangle(base = 0,height = 0):
  tri = Triangle(base,height)
  return"Area of Triangle is {}".format(tri.area())

if __name__ == '__main__':
  app.run(host='0.0.0.0' ,port=8080)