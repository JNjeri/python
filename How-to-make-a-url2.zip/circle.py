class circle:
  radius = 0
  diameter = 0
  def __init__(self,base,height):
    self.radius = radius
    self.diameter = diameter
  def area(self):
      return self.radius *self.radius *3.142